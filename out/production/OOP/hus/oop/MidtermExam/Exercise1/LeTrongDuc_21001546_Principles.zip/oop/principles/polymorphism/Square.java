package hus.oop.MidtermExam.Exercise1.polymorphism;

public class Square extends Shape {
    public void show() {
        System.out.println("Đây là phương thức show() của lớp Square");
    }
}
