package hus.oop.MidtermExam.Exercise1.polymorphism;

public class Shape {
    public void show() {
        System.out.println("Đây là phương thức show() của lớp Shape");
    }
}
