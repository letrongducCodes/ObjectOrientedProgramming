package oop.principles.abstraction;

public class Cat extends Animal {
    @Override
    public void greets() {
        System.out.println("Meo meo");
    }
}
