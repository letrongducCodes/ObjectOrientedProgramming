package oop.principles.abstraction;

public class Dog extends Animal {
    @Override
    public void greets() {
        System.out.println("Gâu gâu");
    }
}
