package hus.oop.MidtermExam.Exercise1.polymorphism;

public class Rectangle extends Shape {
    public void show() {
        System.out.println("Đây là phương thức show() của lớp Rectangle");
    }
}
