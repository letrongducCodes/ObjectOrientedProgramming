package oop.principles.inheritance;

public class Employee {
    protected double salary;

    public Employee() {
    }

    public Employee(double salary) {
        this.salary = salary;
    }
}
