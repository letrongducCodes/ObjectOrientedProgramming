package oop.principles.abstraction;

public abstract class Animal {
    private String greets;

    public abstract void greets();
}
