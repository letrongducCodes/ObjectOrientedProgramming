package hus.oop.midterm.books;

public interface BookComparator {
    int compare(Book left, Book right);
}
