package hus.oop.lab9.Polynomials;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class ListPoly extends AbstractPoly {
    LinkedList<Double> coefficients;

    public ListPoly() {
        coefficients = new LinkedList<>();
    }

    public ListPoly(double[] coeffs) {
        for (int i = 0; i < coeffs.length; i++) {
            this.coefficients.add(coeffs[i]);
        }
    }

    @Override
    public int degree() {
        return coefficients.size();
    }

    @Override
    public Poly derivative() {
        return new ListPoly((derive()));
    }

    @Override
    public double coefficient(int degree) {
        return this.coefficients.get(degree);
    }

    @Override
    public double[] coefficients() {
        double[] coeffs = new double[this.coefficients.size()];
        for (int i = 0; i < coeffs.length; i++) {
            coeffs[i] = this.coefficients.get(i);
        }
        return coeffs;
    }
}
