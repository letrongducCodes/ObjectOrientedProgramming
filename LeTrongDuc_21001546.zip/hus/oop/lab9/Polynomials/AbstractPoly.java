package hus.oop.lab9.Polynomials;

import java.util.Objects;

public abstract class AbstractPoly implements Poly {
    double[] derive() {
        double[] polyCoefs = this.coefficients();
        int polyDegree = this.degree();
        double[] derivativeCoefs = new double[polyDegree - 1];
        for (int i = 0; i < derivativeCoefs.length - 1; i++) {
            derivativeCoefs[i] = polyCoefs[i + 1] * (i + 1);
        }
        return derivativeCoefs;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if(!(o instanceof AbstractPoly)) {
            return false;
        }
        AbstractPoly abstractPoly = (AbstractPoly) o;
        return Objects.equals(coefficients(),abstractPoly.coefficients());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(coefficients());
    }

    @Override
    public String toString() {
        StringBuilder result = new StringBuilder();
        for (int i = 0 ; i < coefficients().length - 1; i++) {
            result.append(coefficients()[i])
                    .append("x^")
                    .append(i)
                    .append(" + ");
        }
        result.append(coefficients()[coefficients().length - 1])
                .append("x^")
                .append(coefficients().length - 1);
        return result.toString();
    }
}
