package hus.oop.lab9.Polynomials;

public class ArrayPoly extends AbstractPoly {
    private final double[] coefficients;

    public ArrayPoly(double[] coefficients) {
        this.coefficients = coefficients;
    }

    @Override
    public int degree() {
        return coefficients.length - 1;
    }

    @Override
    public Poly derivative() {
        double[] derivativeCoefficients = derive();
        return new ArrayPoly(derivativeCoefficients);
    }

    @Override
    public double coefficient(int degree) {
        if (degree < 0 || degree >= coefficients.length) {
            return 0;
        }
        return coefficients[degree];
    }

    @Override
    public double[] coefficients() {
        double[] polyCoefs = coefficients;
        int polyDegree = this.degree();
        double[] derivativeCoefs = new double[polyDegree - 1];
        for (int i = 1; i < polyDegree - 1; i++) {
            derivativeCoefs[i] = polyCoefs[i + 1] * (i + 1);
        }
        return derivativeCoefs;
    }
}
