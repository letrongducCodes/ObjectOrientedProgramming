package hus.oop.lab11.FactoryMethodPattern.Exercise2;

public enum BankType {

    VIETCOMBANK, TPBANK;

}
