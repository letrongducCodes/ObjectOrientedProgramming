package hus.oop.lab11.FactoryMethodPattern.Exercise2;

public class TPBank implements Bank {

    @Override
    public String getBankName() {
        return "TPBank";
    }

}
