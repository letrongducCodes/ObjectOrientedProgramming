package hus.oop.lab11.FactoryMethodPattern.Exercise2;

public class VietcomBank implements Bank {

    @Override
    public String getBankName() {
        return "VietcomBank";
    }

}
