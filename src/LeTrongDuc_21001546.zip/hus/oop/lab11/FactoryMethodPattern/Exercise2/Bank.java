package hus.oop.lab11.FactoryMethodPattern.Exercise2;

public interface Bank {
    String getBankName();
}