package hus.oop.lab11.FactoryMethodPattern.Exercise3;

public interface Fruit {
    public void produceJuice();
}
