package hus.oop.lab11.FactoryMethodPattern.Pseudocode;

public interface Button {
    void render();
    void onClick();
}
