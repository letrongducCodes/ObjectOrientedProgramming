package hus.oop.lab11.FactoryMethodPattern.Pseudocode;

public class Client {
    public static void main(String[] args) {
        Application app = new Application();
        app.main();
    }
}
