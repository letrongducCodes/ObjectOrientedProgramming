package hus.oop.lab11.CommandPattern.Exercise1;

public interface Command {
    void execute();
}
