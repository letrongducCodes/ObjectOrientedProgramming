package hus.oop.lab11.VisitorPattern.Exercise1;

public interface Book {
    void accept(Visitor v);
}
