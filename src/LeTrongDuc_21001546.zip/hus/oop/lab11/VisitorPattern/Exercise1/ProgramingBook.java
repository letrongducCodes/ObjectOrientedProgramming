package hus.oop.lab11.VisitorPattern.Exercise1;

public interface ProgramingBook extends Book {
    String getResource();
}
