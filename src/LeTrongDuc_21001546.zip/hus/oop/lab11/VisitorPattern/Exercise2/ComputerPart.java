package hus.oop.lab11.VisitorPattern.Exercise2;

public interface ComputerPart {
    void accept(ComputerPartVisitor computerPartVisitor);
}
