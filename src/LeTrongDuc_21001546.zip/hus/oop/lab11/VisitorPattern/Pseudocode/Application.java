package hus.oop.lab11.VisitorPattern.Pseudocode;

public class Application {
    private static List<Shape> shapes = new ArrayList<>();
    public static void export() {
        Visitor exportVisitor = new XMLExportVisitor();
        for (Shape shape : shapes) {
            System.out.println();
            shape.accept(exportVisitor);
        }

    }

    public static void main(String[] args) {
        Shape dot = new Dot();
        Shape circle = new Circle();
        Shape rectangle = new Rectangle();
        Shape compoundShape = new CompoundShape();

        shapes.add(dot);
        shapes.add(circle);
        shapes.add(rectangle);
        shapes.add(compoundShape);

        export();
    }
}
