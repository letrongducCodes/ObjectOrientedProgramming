package hus.oop.lab11.VisitorPattern.Pseudocode;

public class Dot implements Shape {
    private int a = 0;
    private int b = 0;

    public Dot() {

    }

    public Dot(int a, int b) {
        this.a = a;
        this.b = b;
    }
    @Override
    public void move(int x, int y) {
        a += x;
        b += y;
    }

    @Override
    public void draw() {
        System.out.println("(" + a + ", " + b +")");
    }

    @Override
    public void accept(Visitor v) {
        v.visitDot(this);
    }
}
