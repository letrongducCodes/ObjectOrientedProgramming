package hus.oop.lab11.VisitorPattern.Pseudocode;

public class Circle implements Shape {
    private int radius = 1;
    public Circle() {
        super();
    }
    @Override
    public void move(int x, int y) {
        super.move(x,y);
    }

    @Override
    public void draw() {
        System.out.print("center = ");
        super.draw();
        System.out.println("radius = " + radius);
    }

    @Override
    public void accept(Visitor v) {
        v.visitCircle(this);
    }
}
