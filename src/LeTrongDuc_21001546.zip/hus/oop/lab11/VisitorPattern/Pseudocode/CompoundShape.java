package hus.oop.lab11.VisitorPattern.Pseudocode;

public class CompoundShape implements Shape {
    public CompoundShape() {
        super();
    }

    @Override
    public void move(int x, int y) {
        super.move(x,y);
    }

    @Override
    public void draw() {
        System.out.print("center = ");
        super.draw();
        System.out.println("Drawing CompoundShape");
    }

    @Override
    public void accept(Visitor v) {
        v.visitCompoundShape(this);
    }
}
