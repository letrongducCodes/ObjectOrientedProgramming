package hus.oop.lab11.VisitorPattern.Pseudocode;

public class Rectangle implements Shape {
    private Dot topLeft;
    private Dot bottomRight;
    private int width = 1;
    private int length = 2;

    public Rectangle() {
        topLeft = new Dot(0, 1);
        bottomRight = new Dot(1, 0);
    }
    @Override
    public void move(int x, int y) {
        topLeft.move(x,y);
        bottomRight.move(x, y);
    }

    @Override
    public void draw() {
        System.out.print("topLeft = ");
        topLeft.draw();
        System.out.print("bottomRight = ");
        bottomRight.draw();
        System.out.println("width = " + width + ", " + "length = " + length);
    }

    @Override
    public void accept(Visitor v) {
        v.visitRectangle(this);
    }
}
