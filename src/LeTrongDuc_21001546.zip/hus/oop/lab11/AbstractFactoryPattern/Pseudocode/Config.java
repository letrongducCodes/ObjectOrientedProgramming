package hus.oop.lab11.AbstractFactoryPattern.Pseudocode;

public class Config {
        public String OS;

        public Config(String OS) {
                this.OS = OS;
        }
}
