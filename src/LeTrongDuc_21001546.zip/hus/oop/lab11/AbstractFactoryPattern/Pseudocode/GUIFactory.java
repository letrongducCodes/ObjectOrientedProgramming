package hus.oop.lab11.AbstractFactoryPattern.Pseudocode;

public interface GUIFactory {
    Button createButton();
    Checkbox createCheckbox();
}
