package hus.oop.lab11.AbstractFactoryPattern.Pseudocode;

public interface Button {
    void paint();
}
