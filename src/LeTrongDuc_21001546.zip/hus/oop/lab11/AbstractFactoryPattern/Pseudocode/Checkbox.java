package hus.oop.lab11.AbstractFactoryPattern.Pseudocode;

public interface Checkbox {
    void paint();
}
