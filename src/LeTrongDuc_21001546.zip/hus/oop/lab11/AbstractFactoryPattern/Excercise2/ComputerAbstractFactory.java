package hus.oop.lab11.AbstractFactoryPattern.Excercise2;

public interface ComputerAbstractFactory {
    public Computer createComputer();
}
