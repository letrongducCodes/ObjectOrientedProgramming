package hus.oop.lab11.AbstractFactoryPattern.Exercise3;

public class Square extends Shape {
    @Override
    public void draw() {
        System.out.println("Drawing square");
    }
}
