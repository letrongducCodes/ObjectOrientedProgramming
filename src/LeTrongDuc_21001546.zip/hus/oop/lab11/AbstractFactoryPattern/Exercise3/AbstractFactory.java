package hus.oop.lab11.AbstractFactoryPattern.Exercise3;

public interface AbstractFactory {
    Shape getRectangle();
    Shape getSquare();
}
