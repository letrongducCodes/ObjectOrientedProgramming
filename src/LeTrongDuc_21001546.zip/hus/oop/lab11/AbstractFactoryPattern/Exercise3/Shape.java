package hus.oop.lab11.AbstractFactoryPattern.Exercise3;

public abstract class Shape {
    public abstract void draw();
}
