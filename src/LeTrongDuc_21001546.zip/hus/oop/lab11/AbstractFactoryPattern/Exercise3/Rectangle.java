package hus.oop.lab11.AbstractFactoryPattern.Exercise3;

public class Rectangle extends Shape {
    @Override
    public void draw() {
        System.out.println("Drawing rectangle");
    }
}
