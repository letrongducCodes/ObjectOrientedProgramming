package hus.oop.lab11.BridgePattern.Exercise1;

public interface OperatingSystem {
    void startup();
    void loadUrl(String url);
}
