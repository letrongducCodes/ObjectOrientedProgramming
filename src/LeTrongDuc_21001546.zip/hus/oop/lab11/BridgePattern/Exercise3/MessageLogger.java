package hus.oop.lab11.BridgePattern.Exercise3;

public interface MessageLogger {
    public void log(String msg);
}
