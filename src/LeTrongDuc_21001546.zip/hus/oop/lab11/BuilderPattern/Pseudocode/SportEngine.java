package hus.oop.lab11.BuilderPattern.Pseudocode;

public class SportEngine extends Engine {
    @Override
    public String engineType() {
        return "Sport Engine";
    }
}
