package hus.oop.lab11.BuilderPattern.Pseudocode;

public class SUVEngine extends Engine {
    @Override
    public String engineType() {
        return "SUV Engine";
    }
}
