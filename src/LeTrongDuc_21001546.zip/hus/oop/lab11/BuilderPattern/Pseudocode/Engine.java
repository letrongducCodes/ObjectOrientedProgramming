package hus.oop.lab11.BuilderPattern.Pseudocode;

public abstract class Engine {
    public abstract String engineType();
}
