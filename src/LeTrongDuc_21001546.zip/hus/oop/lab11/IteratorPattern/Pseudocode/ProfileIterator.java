package hus.oop.lab11.IteratorPattern.Pseudocode;

public interface ProfileIterator {
    Profile getNext();
    boolean hasMore();
}
