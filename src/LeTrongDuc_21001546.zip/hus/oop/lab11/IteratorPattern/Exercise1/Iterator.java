package hus.oop.lab11.IteratorPattern.Exercise1;

public interface Iterator {
    boolean hasNext();
    Object next();
}
