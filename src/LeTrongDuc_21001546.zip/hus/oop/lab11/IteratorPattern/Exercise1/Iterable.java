package hus.oop.lab11.IteratorPattern.Exercise1;

public interface Iterable {
    Iterator getIterator();
}
