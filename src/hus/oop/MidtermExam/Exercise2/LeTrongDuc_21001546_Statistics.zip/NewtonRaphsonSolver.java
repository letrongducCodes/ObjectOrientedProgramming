
public class NewtonRaphsonSolver implements RootSolver {
    private double tolerance;
    private int maxIterations;

    /**
     * Khởi tạo giá trị các tham số.
     * @param tolerance
     * @param maxIterations
     */
    public NewtonRaphsonSolver(double tolerance, int maxIterations) {
        /* TODO */
        this.tolerance = tolerance;
        this.maxIterations = maxIterations;
    }

    /**
     * Tìm nghiệm của đa thức sử dụng phương pháp Newton-Raphson.
     * @param polynomial
     * @param lower
     * @param upper
     * @return nghiệm của đa thức.
     */
    @Override
    public double solve(Polynomial polynomial, double lower, double upper) {
        /* TODO */
        double x0 = (lower + upper) / 2.0;
        double x = x0;

        for (int i = 0; i < maxIterations; ++i) {
            double fx = polynomial.evaluate(x);
            double fpx = polynomial.evaluateDerivative(x);

            if (Math.abs(fpx) < tolerance) {
                throw new ArithmeticException("Division by zero!");
            }

            double dx = fx / fpx;
            x -= dx;

            if (Math.abs(dx) < tolerance * Math.abs(x) || Math.abs(fx) < tolerance) {
                return x;
            }
        }
        throw new ArithmeticException("Failed to converge in " + maxIterations + " iterations!");
    }
}
