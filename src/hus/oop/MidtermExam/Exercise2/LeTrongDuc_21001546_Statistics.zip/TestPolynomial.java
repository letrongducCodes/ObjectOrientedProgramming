
public class TestPolynomial {
    public static void main(String[] args) {
        /*
         TODO

         - Chạy demo các hàm test.
         - Lưu kết quả chạy chương trình vào file text có tên <Ten_MaSinhVien_MyList>.txt
           (ví dụ, NguyenVanA_123456_MyList.txt)
         - Nộp kết quả chạy chương trình (file text trên) cùng với các file source code.
         */
        testArrayPolynomial();
        System.out.println();
        testListPolynomial();
        System.out.println();
        testRootSolver();
    }

    public static void testArrayPolynomial() {
        /*
         TODO

         - Viết chương trình test các chức năng của ArrayPolynomial (thêm phần tử vào đa thức, xóa phần tử trong đa thức,
           sửa hệ số tại một phần tử, cộng 2 đa thức, trừ 2 đa thức, nhân 2 đa thức, tính giá trị của đa thức khi biết
           giá trị của x).
         */
        ArrayPolynomial arrayPolynomial = new ArrayPolynomial(new double[] {1,3,4,8});
        ArrayPolynomial arrayPolynomial1 = new ArrayPolynomial(new double[] {1,3,4,5});
        System.out.println("Đa thức 1: " + arrayPolynomial);
        System.out.println("Đa thức 2: " + arrayPolynomial1);
        System.out.println("Đa thức 1 sau khi thêm phần tử vào là: " + arrayPolynomial.append(2.0));
        System.out.println("Đa thức 1 sau khi sửa hệ số tại 1 phần tử là: " + arrayPolynomial.set(5.0,1));
        System.out.println("Tổng của 2 đa thức là: " + arrayPolynomial.plus(arrayPolynomial1));
        System.out.println("Hiệu của 2 đa thức là: " + arrayPolynomial.minus(arrayPolynomial1));
        System.out.println("Tích của 2 đa thức là: " + arrayPolynomial.multiply(arrayPolynomial1));
        System.out.println("Giá trị của đa thức 1 tại x = 2.0 là: " + arrayPolynomial.evaluate(2.0));
        System.out.println("Giá trị của đa thức 2 tại x = 2.0 là: " + arrayPolynomial1.evaluate(2.0));
    }

    public static void testListPolynomial() {
        /*
         TODO

         - Viết chương trình test các chức năng của ListPolynomial (thêm phần tử vào đa thức, xóa phần tử trong đa thức,
           sửa hệ số tại một phần tử, cộng 2 đa thức, trừ 2 đa thức, nhân 2 đa thức, tính giá trị của đa thức khi biết
           giá trị của x).
         */
        ListPolynomial listPolynomial = new ListPolynomial();
        listPolynomial.append(1);
        listPolynomial.append(3);
        listPolynomial.append(4);
        listPolynomial.append(8);
        System.out.println("Đa thức 1: " + listPolynomial);
        System.out.println("Đa thức 1 sau khi sửa hệ số tại 1 phần tử là: " + listPolynomial.set(2,1));
        ListPolynomial listPolynomial1 = new ListPolynomial();
        listPolynomial1.append(1);
        listPolynomial1.append(3);
        listPolynomial1.append(4);
        listPolynomial1.append(5);
        System.out.println("Đa thức 2: " + listPolynomial1);
        System.out.println("Tổng của 2 đa thức là: " + listPolynomial.plus(listPolynomial1));
        System.out.println("Hiệu của 2 đa thức là: " + listPolynomial.minus(listPolynomial1));
        System.out.println("Tích của 2 đa thức là: " + listPolynomial.multiply(listPolynomial1));
        System.out.println("Giá trị của đa thức 1 tại x = 2.0 là: " + listPolynomial.evaluate(2.0));
        System.out.println("Giá trị của đa thức 2 tại x = 2.0 là: " + listPolynomial1.evaluate(2.0));
    }

    public static void testRootSolver() {
        /*
         TODO

         - Tạo đa thức có nghiệm trong khoảng [a, b] nào đó.
         - Viết chương trình tìm nghiệm của đa thức theo các phương pháp đã cho (Bisection, Newton-Raphson, Secant) sử dụng
           PolynomialRootFinding. Các phương pháp tìm nghiệm của thể thay đổi ở thời gian chạy chương trình.
         - In ra phương pháp sử dụng, đa thức, và nghiệm của đa thức.
         */
        ArrayPolynomial arrayPolynomial = new ArrayPolynomial(new double[] {1,3,3,1});
        System.out.println("Đa thức: " + arrayPolynomial);
        NewtonRaphsonSolver newtonRaphsonSolver = new NewtonRaphsonSolver(0.0001,100);
        System.out.println("Nghiệm của đa thức theo phương pháp Newton-Raphson là: " + newtonRaphsonSolver.solve(arrayPolynomial,-100,100));
        SecantSolver secantSolver = new SecantSolver(0.0001,100); //Theo em tìm hiểu được thì Secant sẽ sai số một ít
        System.out.println("Nghiệm của đa thức theo phương pháp Secant là: " +secantSolver.solve(arrayPolynomial,-100,100));
        BisectionSolver bisectionSolver = new BisectionSolver(0.0001,100);
        System.out.println("Nghiệm của đa thức theo phương pháp Bisection là: " +bisectionSolver.solve(arrayPolynomial,-100,100));
        PolynomialRootFinding polynomialRootFinding =new PolynomialRootFinding(arrayPolynomial,newtonRaphsonSolver);
        System.out.println("Nghiệm của đa thức theo phương pháp Newton-Raphson sử dụng PolynomialRootFinding là: "
                + polynomialRootFinding.solve(-100,100));
        PolynomialRootFinding polynomialRootFinding1 =new PolynomialRootFinding(arrayPolynomial,secantSolver);
        System.out.println("Nghiệm của đa thức theo phương pháp Secant sử dụng PolynomialRootFinding là: "
                + polynomialRootFinding1.solve(-100,100));
        PolynomialRootFinding polynomialRootFinding2 =new PolynomialRootFinding(arrayPolynomial,bisectionSolver);
        System.out.println("Nghiệm của đa thức theo phương pháp Bisection sử dụng PolynomialRootFinding là: "
                + polynomialRootFinding2.solve(-100,100));
    }
}
