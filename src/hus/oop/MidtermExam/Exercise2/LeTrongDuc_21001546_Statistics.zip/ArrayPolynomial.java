
import java.util.*;

public class ArrayPolynomial extends AbstractPolynomial {
    private static final int DEFAULT_CAPACITY = 2;
    private double[] coefficents;
    private int size;

    /**
     * Khởi tạo dữ liệu mặc định.
     */
    public ArrayPolynomial(double[] derivativeCoefficients) {
        /* TODO */
        coefficents = derivativeCoefficients;
        size = coefficents.length;
    }

    /**
     * Lấy hệ số của đa thức tại phần tử index
     * @return hệ số tại phần tử index.
     */
    @Override
    public double coefficient(int index) {
        /* TODO */
        if (index < 0 || index >= coefficents.length) {
            return 0;
        }
        return coefficents[index];
    }

    /**
     * Lấy mảng các hệ số của đa thức.
     * @return mảng các hệ số của đa thức.
     */
    @Override
    public double[] coefficients() {
        /* TODO */
        double[] polyCoeffs = coefficents;
        return polyCoeffs;
    }

    /**
     * Thêm một phần tử có hệ số coefficient vào cuối đa thức.
     * @param coefficient
     * @return đa thức hiện tại.
     */
    public ArrayPolynomial append(double coefficient) {
        /* TODO */
        double[] newCoefficients = new double[coefficents.length + 1];
        System.arraycopy(coefficents, 0, newCoefficients, 0, coefficents.length);
        newCoefficients[coefficents.length] = coefficient;
        coefficents = newCoefficients;
        return new ArrayPolynomial(coefficents);
    }

    /**
     * Thêm một phần tử có hệ số coefficient vào vị trí index.
     * @param coefficient
     * @param index
     * @return đa thức hiện tại.
     */
    public ArrayPolynomial insert(double coefficient, int index) {
        /* TODO */
        if (index < 0 || index > coefficents.length) {
            throw new IndexOutOfBoundsException("Index " + index + " is out of bounds for polynomial of degree " + (coefficents.length - 1));
        }
        double[] newCoefficients = new double[coefficents.length + 1];
        System.arraycopy(coefficents, 0, newCoefficients, 0, index);
        newCoefficients[index] = coefficient;
        System.arraycopy(coefficents, index, newCoefficients, index + 1, coefficents.length - index);
        coefficents = newCoefficients;
        return new ArrayPolynomial(coefficents);
    }

    /**
     * Thay đổi hệ số của đa thức tại phần tử index.
     * @param coefficient
     * @param index
     * @return đa thức hiện tại.
     */
    public ArrayPolynomial set(double coefficient, int index) {
        /* TODO */
        if (index < 0 || index >= coefficents.length) {
            throw new IndexOutOfBoundsException("Index " + index + " is out of bounds for polynomial of degree " + (coefficents.length - 1));
        }
        coefficents[index] = coefficient;
        return new ArrayPolynomial(coefficents);
    }

    /**
     * Lấy bậc của đa thức.
     * @return bậc của đa thức.
     */
    @Override
    public int degree() {
        /* TODO */
        int degree = coefficents.length - 1;
        for (int i = coefficents.length - 1; i > 0 ; i--) {
            if (coefficents[i] == 0) {
                degree--;
            } else {
                break;
            }
        }
        return degree;
    }

    /**
     * Tính giá trị của đa thức khi biết giá trị của x.
     * @return giá trị của đa thức.
     */
    @Override
    public double evaluate(double x) {
        /* TODO */
        double result = this.coefficents[this.coefficents.length - 1];
        for (int i = this.coefficents.length - 2; i >= 0; i--) {
            result = result * x + this.coefficents[i];
        }
        return result;
    }

    /**
     * Lấy đạo hàm của đa thức.
     * @return Đa thức kiểu ArrayPolynomial là đa thức đạo hàm của đa thức hiện tại.
     */
    @Override
    public Polynomial derivative() {
        /* TODO */
        double[] derivativeCoefficients = differentiate();
        return new ArrayPolynomial(derivativeCoefficients);
    }

    /**
     * Cộng một đa thức khác vào đa thức hiện tại.
     * @param another
     * @return đa thức hiện tại.
     */
    public ArrayPolynomial plus(ArrayPolynomial another) {
        /* TODO */
        int maxDegree = Math.max(coefficents.length, another.coefficents.length);
        double[] sumCoefficients = new double[maxDegree];
        for (int i = 0; i < maxDegree; i++) {
            double a = (i < coefficents.length) ? coefficents[i] : 0.0;
            double b = (i < another.coefficents.length) ? another.coefficents[i] : 0.0;
            sumCoefficients[i] = a + b;
        }
        return new ArrayPolynomial(sumCoefficients);
    }

    /**
     * Trừ đa thức hiện tại với đa thức khác.
     * @param another
     * @return đa thức hiện tại.
     */
    public ArrayPolynomial minus(ArrayPolynomial another) {
        /* TODO */
        int maxDegree = Math.max(coefficents.length, another.coefficents.length);
        double[] diffCoefficients = new double[maxDegree];
        for (int i = 0; i < maxDegree; i++) {
            double a = (i < coefficents.length) ? coefficents[i] : 0.0;
            double b = (i < another.coefficents.length) ? another.coefficents[i] : 0.0;
            diffCoefficients[i] = a - b;
        }
        return new ArrayPolynomial(diffCoefficients);
    }

    /**
     * Nhân đa thức hiện tại với đa thức khác.
     * @param another
     * @return đa thức hiện tại.
     */
    public ArrayPolynomial multiply(ArrayPolynomial another) {
        /* TODO */
        int degree = coefficents.length + another.coefficents.length - 1;
        double[] productCoefficients = new double[degree];
        for (int i = 0; i < coefficents.length; i++) {
            for (int j = 0; j < another.coefficents.length; j++) {
                productCoefficients[i + j] += coefficents[i] * another.coefficents[j];
            }
        }
        return new ArrayPolynomial(productCoefficients);
    }

    /**
     * Thêm kích thước để lưu đa thức khi cần thiết.
     */
    private void enlarge() {
        /* TODO */
        double[] tmp = new double[coefficents.length * 2];
        System.arraycopy(coefficents,0,tmp,0,coefficents.length);
        this.coefficents = tmp;
    }

    public double evaluateDerivative(double x) {
        double result = 0.0;
        for (int i = coefficents.length - 1; i >= 1; i--) {
            result = result * x + i * coefficents[i];
        }
        return result;
    }
}
